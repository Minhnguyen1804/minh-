### [Hướng dẫn tạo website tỏ tình 2021 đơn giản || Part 1](https://youtu.be)
> Các bạn download source về và làm theo hướng dẫn trong video nhé.


![cover picture](/img/totinh2021-part1.jpg)
